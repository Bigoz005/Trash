CREATE DATABASE [209334_sr_12_14_gr2];

-- 2.1
USE [209334_sr_12_14_gr2];

CREATE TABLE [Produkty]
(
	ID_Produktu BIGINT NOT NULL,
	Nazwa VARCHAR(40) NOT NULL,
	Kategoria VARCHAR(MAX),
	Cena_Jednostkowa MONEY DEFAULT 0
);

ALTER TABLE Produkty ADD CONSTRAINT PK_ID_Produktu PRIMARY KEY(ID_Produktu);

INSERT INTO [Produkty](ID_Produktu,Nazwa,Kategoria,Cena_Jednostkowa)
	SELECT npp.IDProduktu, npp.NazwaProduktu, npk.NazwaKategorii, npp.CenaJednostkowa FROM north_pl.dbo.Produkty AS npp
	INNER JOIN north_pl.dbo.Kategorie AS npk ON npk.IDkategorii = npp.IDkategorii
	WHERE CenaJednostkowa BETWEEN 25 AND 60;

-- 2.2

USE [209334_sr_12_14_gr2];

SELECT o.OrderID, c.CompanyName AS Nazwa_klienta, o.OrderDate, o.ShippedDate, s.CompanyName AS Nazwa_dostawcy, p.ProductID, od.Quantity, od.UnitPrice FROM  NORTHWND.dbo.Orders AS o
INNER JOIN NORTHWND.dbo.Customers AS c ON c.CustomerID = o.CustomerID
INNER JOIN NORTHWND.dbo.[Order Details] AS od ON od.OrderID = o.OrderID
INNER JOIN NORTHWND.dbo.Products AS p ON p.ProductID = od.ProductID
INNER JOIN NORTHWND.dbo.Suppliers AS s ON s.SupplierID = p.SupplierID
WHERE EXISTS(SELECT Nazwa FROM Produkty AS po WHERE po.ID_Produktu = p.ProductID)ORDER BY o.OrderID 




SELECT tab.CompanyName, tab.Suma_Zamowien FROM
(
	SELECT c.CompanyName FROM Customers AS c
	INNER JOIN Orders AS o ON o.CustomerID = c.CustomerID
	INNER JOIN [Order Details] AS od ON od.OrderID = o.OrderID
	GROUP BY CompanyName) AS tab

-- 3.

USE [209334_sr_12_14_gr2];

SELECT TOP 3 tab.Kategoria, tab.Ilosc FROM
(
	SELECT Kategoria , COUNT(ID_Produktu) AS Ilosc FROM Produkty
	GROUP BY Kategoria) AS tab
ORDER BY tab.Ilosc

-- 4.

USE [NORTHWND];

SELECT tab.NazwaFirmy, tab.Suma_Zamowien FROM
(
	SELECT c.CompanyName AS NazwaFirmy, SUM(od.Quantity * od.UnitPrice) AS Suma_zamowien FROM Customers AS c
	INNER JOIN Orders AS o ON o.CustomerID = c.CustomerID
	INNER JOIN [Order Details] AS od ON od.OrderID = o.OrderID
	GROUP BY CompanyName) AS tab
WHERE tab.Suma_zamowien BETWEEN 1000 AND 3000 ORDER BY tab.Suma_zamowien DESC

-- 5.

USE [209334_sr_12_14_gr2];

CREATE VIEW [vProdukty] AS SELECT tab.CompanyName, tab.Ilosc_zlecen FROM(
	SELECT s.CompanyName, SUM(p.UnitsInStock + p.UnitsOnOrder) AS Ilosc_zlecen FROM NORTHWND.dbo.Suppliers AS s
	INNER JOIN NORTHWND.dbo.Products AS p ON p.SupplierID = s.SupplierID
	GROUP BY s.CompanyName) as tab;
	
SELECT TOP 1 * FROM vProdukty ORDER BY Ilosc_zlecen ASC

-- 6.

USE [209334_sr_12_14_gr2];

CREATE VIEW [vProdukty_2] AS SELECT tab.ProductName, tab.