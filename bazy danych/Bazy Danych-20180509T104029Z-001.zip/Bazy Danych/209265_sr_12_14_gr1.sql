--zadanie1
use [master];
go
create database [209265_sr_14_g1];
go
use [209265_sr_14_g1];

--zadanie2.1

create table [Produkty]
(
	ID_Produktu bigint not null  primary key, 
	Nazwa varchar(40) not null,
	Kategoria varchar(max),
	Cena_jednostkowa money default(0)

);

drop table Produkty


insert into [Produkty] (ID_Produktu,Nazwa,Kategoria,Cena_jednostkowa)
	(select p.ProductID,p.ProductName,c.CategoryName,p.UnitPrice 
	from [NORTHWND ENG].[dbo].[Products] p 
	join  [NORTHWND ENG].[dbo].[Categories] c on p.CategoryID=c.CategoryID
	where p.UnitPrice BETWEEN 1 and 20)



--zadanie2.2

select o.OrderID,c.CustomerID,o.OrderDate,o.ShippedDate,s.CompanyName,od.ProductID,od.Quantity,od.UnitPrice  into [Zam�wienia] 
	 
	from [NORTHWND ENG].[dbo].[Orders] o
	join [NORTHWND ENG].[dbo].[Customers] c on c.CustomerID=o.CustomerID
	join [NORTHWND ENG].[dbo].[Shippers] sh on sh.ShipperID=o.ShipVia
	join [NORTHWND ENG].[dbo].[Order Details] od on od.OrderID=o.OrderID
	join [NORTHWND ENG].[dbo].[Products] p on od.ProductID=p.ProductID
	join [NORTHWND ENG].[dbo].[Suppliers] s on s.SupplierID=p.SupplierID

	where p.UnitsInStock>1

(ID_zamowienia,Nazwa,data_zamowienia,data_dostawy,nazwa_dostawcy,ID_produktu, ilosc_zamowienia,unitprice)	


select from customers
use [209265_sr_14_g1];
--zad3

select top 3 Kategoria, z.Quantity as liczba_produktow from Produkty as p
join Zam�wienia z on z.ProductID=p.ID_produktu
group by p.kategoria, z.Quantity 
order by  liczba_produktow desc

--zad4
select c.CompanyName, sum(od.UnitPrice*od.Quantity) from Customers c
join Orders o on o.CustomerID=c.CustomerID
join [Order Details] od on od.OrderID=o.OrderID
group by c.CompanyName
having sum(od.UnitPrice*od.Quantity) BETWEEN 5000 and 12000
order by c.CompanyName asc

use [209265_sr_14_g1];
--zad5
create view [zad5] as 
select top 1 s.CompanyName, Count(o.OrderID) SumaZlecen
from [NORTHWND ENG].[dbo].[Orders]  o
join [NORTHWND ENG].[dbo].[Shippers] s on s.ShipperID=o.ShipVia
group by s.CompanyName
order by SumaZlecen  ASC;




--zad6
drop view zad5
create view [zad6] as 
select top 5 p.ProductName as [nazwa]
from [NORTHWND ENG].[dbo].[Order Details]  od
join [NORTHWND ENG].[dbo].[Products] p on p.ProductID=od.ProductID
where p.ProductName like '[C-P][c-p]%' and p.UnitPrice between '10' and '100' and  p.UnitPrice<>'10' and p.UnitPrice<>97;