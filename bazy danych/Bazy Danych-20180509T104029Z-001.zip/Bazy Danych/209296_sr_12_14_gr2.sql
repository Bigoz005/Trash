--zad 1
use [master];
go
create database [209296_sr_12_14_gr2];
go
use [209296_sr_12_14_gr2];

--zadanie2.1

create table [Produkty]
(
	ID_Produktu int not null primary key,
	Nazwa varchar(40) not null,
	Kategoria varchar(max),
	Cena_Jednostkowa money default(0)
);

insert into [Produkty](ID_Produktu,Nazwa,Kategoria,Cena_Jednostkowa)
(select p.ProductID,p.ProductName,c.CategoryName,p.UnitPrice
from [NORTHWND_ENG].[dbo].[Products] as p
inner join [NORTHWND_ENG].[dbo].[Categories] as c on p.CategoryID=c.CategoryID
where p.UnitPrice between 25 and 60
);

--zad 2.2
select o.OrderID, c.CompanyName as klient, o.OrderDate, o.ShippedDate, s.CompanyName as dostawca, p.ProductID, od.Quantity, od.UnitPrice into [Zam�wienia] 
from [NORTHWND_ENG].[dbo].[Products] as p
inner join [NORTHWND_ENG].[dbo].[Suppliers] as s on s.SupplierID = p.SupplierID
inner join [NORTHWND_ENG].[dbo].[Order Details] as od on od.ProductID=p.ProductID
inner join [NORTHWND_ENG].[dbo].[Orders] as o on o.OrderID=od.OrderID
inner join [NORTHWND_ENG].[dbo].[Customers] as c on c.CustomerID=o.CustomerID
where exists (select * from [Produkty]);

--zad 3
select top 3 p.kategoria, z.Quantity from produkty as p
join Zam�wienia as z on p.ID_Produktu=z.ProductID
group by p.kategoria, z.Quantity
order by z.Quantity asc;

--zad 4
select c.CompanyName, sum(od.UnitPrice*od.Quantity) as wartosc from Customers as c
inner join Orders as o on o.CustomerID=c.CustomerID
inner join [Order Details] as od on od.OrderID=o.OrderID
group by c.CompanyName
having sum(od.UnitPrice*od.Quantity) between 1000 and 3000
order by wartosc desc;

--zad 5
create view [Spedytor] as
select s.CompanyName, count(o.OrderID) as [Ilo�� zlece�] 
from [NORTHWND_ENG].[dbo].[orders] as o
inner join [NORTHWND_ENG].[dbo].[Shippers] as s on o.ShipVia=s.ShipperID 
group by s.CompanyName;

select CompanyName, [Ilo�� zlece�] from [Spedytor]
where [Ilo�� zlece�] in (select min([Ilo�� zlece�])from [Spedytor]);

--zad 6
create view [zad6] as 
select p.ProductName as [nazwa],p.UnitPrice as [Cena]
from [NORTHWND_ENG].[dbo].[Products] as p
where p.ProductName like '[C-P][c-p]%' and p.UnitPrice between '10' and '100' and  p.UnitPrice<>'17' and p.UnitPrice<>40;

select top 5 [nazwa],[Cena] from [zad6] 
group by [nazwa],[Cena]
having [Cena] in (select min([Cena])from [Spedytor]);
 
