-- Zadanie 1

Create Database [209312_sr_12_14_gr2];

--Zadanie 2.1

Create Table [Produkty]
(
ID_Produktu INTEGER PRIMARY KEY NOT NULL,
Nazwa varchar(40) NOT NULL,
Kategoria varchar(MAX), 
Cena_Jednostkowa MONEY DEFAULT '0'
);

INSERT INTO [Produkty](ID_Produktu,Nazwa,Kategoria,Cena_Jednostkowa)
(
SELECT Produkty.IDProduktu, Produkty.NazwaProduktu, Kategorie.NazwaKategorii, Produkty.CenaJednostkowa 
from [northwind].[dbo].[Produkty] inner join [northwind].[dbo].[Kategorie] ON Produkty.IDkategorii=Kategorie.IDkategorii
WHERE Produkty.CenaJednostkowa between 25 and 60
);


--Zadanie 4

Wy�wietl nazwy firm oraz sum� warto�ci ich zam�wie� od 1000 do 3000 posortowanych od Z-A po warto�ciach. Baza danych Northwind.


Select  Klienci.NazwaFirmy, SUM([Opisy zam�wie�].Ilo��*[Opisy zam�wie�].CenaJednostkowa) AS Suma
from [northwind].[dbo].[Zam�wienia] inner join [northwind].[dbo].[Opisy zam�wie�] ON Zam�wienia.IDzam�wienia=[Opisy zam�wie�].IDzam�wienia 
inner join [northwind].[dbo].[Klienci] ON Klienci.IDklienta=Zam�wienia.IDzam�wienia
HAVING SUM([Opisy zam�wie�].Ilo��*[Opisy zam�wie�].CenaJednostkowa) between 1000 and 3000
Group BY Klienci.NazwaFirmy desc;


-- ZADANIE 6

CREATE VIEW Zadanie6
As 
select TOP 5
Produkty.NazwaProduktu, Produkty.CenaJednostkowa
from [northwind].[dbo].[Produkty]
Where Produkty.NazwaProduktu between 'c%' and 'p%' and Produkty.CenaJednostkowa between 10 and 100 and Produkty.CenaJednostkowa <>17 and Produkty.CenaJednostkowa<>40
Order by Produkty.CenaJednostkowa asc;

Select * from Zadanie6;
