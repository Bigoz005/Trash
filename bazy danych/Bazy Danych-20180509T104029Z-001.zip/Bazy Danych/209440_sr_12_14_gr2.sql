
/*
ZAD 1

CREATE DATABASE [209440_sr_12_14_gr2]



ZAD 2.1

CREATE TABLE [Produkty]
(
	ID_Produktu BIGINT  not null,
	Nazwa varchar(40) not null,
	Kategoria varchar(max),
	Cena_Jednostkowa MONEY DEFAULT(0)
);


INSERT INTO [Produkty](ID_Produktu, Nazwa, Kategoria, Cena_Jednostkowa) 

	SELECT prod.IDproduktu, prod.NazwaProduktu, cat.IDkategorii ,prod.CenaJednostkowa
	FROM [north].[dbo].[Produkty] as prod
	JOIN [north].[dbo].[Kategorie] AS cat ON cat.IDkategorii = prod.IDkategorii
	WHERE prod.CenaJednostkowa BETWEEN 25 AND 60 





ZAD 2.2

SELECT z.IDzam�wienia, k.NazwaFirmy AS nazwa_Klienta, z.DataZam�wienia,
		 z.DataWymagana AS DataDostawy, s.NazwaFirmy AS Dostawca,
		 oz.IDproduktu, oz.Ilo��, p.CenaJednostkowa
INTO [209440_sr_12_14_gr2].[dbo].[Zamowienia]
FROM [north].[dbo].[Zam�wienia] AS z
JOIN [north].[dbo].[Klienci] AS k ON k.IDklienta = z.IDklienta
JOIN [north].[dbo].[Spedytorzy] AS s ON s.IDspedytora = z.IDspedytora
JOIN [north].[dbo].[Opisy zam�wie�] AS oz ON oz.IDzam�wienia = z.IDzam�wienia
JOIN [north].[dbo].[Produkty] AS p ON p.IDproduktu = oz.IDproduktu



ZAD 3


-- jeszcze nie ma



ZAD 4

SELECT k.nazwafirmy, SUM( o.CenaJednostkowa*o.Ilo�� ) AS wartosc FROM Klienci AS k
	JOIN Zam�wienia AS z ON z.IDklienta = k.IDklienta
	JOIN [Opisy zam�wie�] AS o ON o.IDzam�wienia = z.IDzam�wienia
	GROUP BY k.nazwafirmy
	HAVING SUM( o.CenaJednostkowa*o.Ilo�� ) BETWEEN 1000 AND 3000
	ORDER BY wartosc DESC 





ZAD 5

CREATE VIEW [widok1] AS
SELECT s.NazwaFirmy, COUNT(z.IDspedytora) AS ilosc FROM [north].[dbo].[Spedytorzy] AS s
	JOIN [north].[dbo].[Zam�wienia] AS z ON z.IDspedytora = s.IDspedytora
	GROUP BY s.NazwaFirmy

SELECT TOP 1 * FROM widok1
	ORDER BY ilosc ASC
	


ZAD 6

CREATE VIEW [widok2] AS 
SELECT p.NazwaProduktu, p.CenaJednostkowa FROM [north].[dbo].[Produkty] AS p
	WHERE p.NazwaProduktu LIKE '[c-p]%' AND 
	p.CenaJednostkowa BETWEEN 10 AND 100 AND
	p.CenaJednostkowa NOT IN (17, 40)

SELECT TOP 5 * FROM widok2
	ORDER BY CenaJednostkowa ASC
*/





