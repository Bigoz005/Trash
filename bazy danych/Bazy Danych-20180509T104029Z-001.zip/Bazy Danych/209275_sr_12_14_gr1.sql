--Zadanie 1

CREATE DATABASE [209275_sr_12_14_gr1]

--Zadanie 2

USE [209275_sr_12_14_gr1]


CREATE TABLE [Produkty]
(
ID_Produktu INT NOT NULL,
Nazwa VARCHAR(40) NOT NULL,
Kategoria VARCHAR(MAX),
Cena_Jednostkowa MONEY DEFAULT 0
);
--INSERT INTO [Produkty](ID_Produktu, Nazwa, Kategoria, Cena_Jednostkowa)
SELECT *FROM [NORTHWND ENG].[dbo].Orders  


) 

--ZADANIE 5

USE [NORTHWND ENG]

Create View [widok1]
AS
(SELECT s.CompanyName as nazwa, COUNT(o.OrderID) as liczba_zlecen FROM Orders AS o
JOIN Shippers AS s on s.ShipperID = o.ShipVia
GROUP BY s.CompanyName
--ORDER BY liczba_zlecen
);


SELECT TOP 1 * FROM widok1 ORDER BY liczba_zlecen desc;

--ZADANIE 4

SELECT s.CompanyName as nazwa, (od.UnitPrice) as wartosc_zlecenia From [Order Details] AS od
JOIN Shippers as S ON s.ShipperID = od.ProductID
JOIN Products as p ON s.ShipperID = p.SupplierID
WHERE od.UnitPrice BETWEEN 5000 AND 12000
GROUP BY CompanyName;


--ZADANIE 6

USE [209275_sr_12_14_gr1]

CREATE VIEW [vProdukty]
AS 
SELECT ProductName, UnitPrice from [NORTHWND ENG].[dbo].Products
 WHERE ProductName LIKE 'c-p&'
 AND UnitPrice BETWEEN 10 AND 100
 AND UnitPrice <> 10
 AND UnitPrice <> 97;

 SELECT TOP 5 * FROM [vProdukty] ORDER BY UnitPrice;