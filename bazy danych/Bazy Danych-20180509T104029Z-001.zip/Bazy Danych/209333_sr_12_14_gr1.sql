-- 1
CREATE DATABASE [209333_sr_12_14_gr1]; 

------2.1
USE [209333_sr_12_14_gr1]

CREATE TABLE [Produkty]
(
	ID_Produktu INT NOT NULL PRIMARY KEY,
	Nazwa VARCHAR(40) NOT NULL,
	Kategoria VARCHAR(max),
	Cena_Jednostkowa MONEY default(0)
)

SELECT * FROM Produkty;

INSERT INTO [Produkty](ID_Produktu,Nazwa,Kategoria,Cena_Jednostkowa)
			(SELECT p.ProductID,p.ProductName,c.CategoryName,p.UnitPrice 
			FROM [Northwind].[dbo].Products AS p
			JOIN  [Northwind].[dbo].Categories AS c ON p.CategoryID = c.CategoryID
			WHERE p.UnitPrice BETWEEN 1 AND 20);

-- 2.2

SELECT  o.OrderID,c.CompanyName AS Customer ,o.OrderDate,o.RequiredDate,s.CompanyName AS Shipper,p.ProductID,
		od.Quantity,od.UnitPrice INTO [Zam�wienia] FROM [Northwind].[dbo].Orders AS o
		JOIN [Northwind].[dbo].Customers AS c ON o.CustomerID = c.CustomerID
		JOIN [Northwind].[dbo].Shippers AS s ON o.ShipVia = s.ShipperID
		JOIN [Northwind].[dbo].[Order Details] AS od ON o.OrderID = od.OrderID
		JOIN [Northwind].[dbo].Products AS p ON od.ProductID = p.ProductID
		WHERE p.ProductID IN (SELECT ID_Produktu FROM  Produkty);
-- 3

SELECT TOP 3 Kategoria,COUNT(ID_Produktu) FROM Produkty	
GROUP BY kategoria ORDER BY COUNT(ID_Produktu) DESC;
	
-- 4

USE [Northwind]

SELECT c.CompanyName, SUM(od.UnitPrice*od.Quantity) AS [wart_zam] FROM Customers AS c
JOIN Orders AS o ON o.CustomerID = c.CustomerID
JOIN [Order Details] AS od ON o.OrderID = od.OrderID
GROUP BY c.CompanyName
HAVING SUM(od.UnitPrice*od.Quantity) > 5000 AND SUM(od.UnitPrice*od.Quantity) < 12000
ORDER BY SUM(od.UnitPrice*od.Quantity) ASC;

-- 5 
USE [209333_sr_12_14_gr1]

CREATE VIEW [zlecenia]
AS
(
SELECT sh.CompanyName,COUNT(o.OrderID) AS ilosc_zlec FROM [Northwind].[dbo].Shippers AS sh
JOIN [Northwind].[dbo].[Orders] AS o ON o.ShipVia = sh.ShipperID 
GROUP BY sh.CompanyName);

SELECT CompanyName,ilosc_zlec FROM zlecenia
WHERE ilosc_zlec IN(SELECT MAX(ilosc_zlec) FROM zlecenia)
GROUP BY CompanyName,ilosc_zlec;

--6 
CREATE VIEW [v_prod]
AS
(
SELECT ProductName,UnitPrice FROM [Northwind].[dbo].Products
WHERE ProductName LIKE '[C-P c-p]%' AND
UnitPrice BETWEEN 10 AND 100
AND UnitPrice <> 10 AND UnitPrice <> 97);

SELECT ProductName FROM v_prod 
WHERE ProductName IN (
SELECT TOP 5 ProductName,UnitPrice FROM v_prod
GROUP BY  ProductName,UnitPrice ORDER BY UnitPrice DESC);