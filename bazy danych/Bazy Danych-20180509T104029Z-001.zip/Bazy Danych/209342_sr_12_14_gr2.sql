/*
Zadanie 1
CREATE DATABASE [209342_sr_12_14_gr2]


Zadanie 2.1
CREATE TABLE [Produkty](
	ID_Produktu INT PRIMARY KEY NOT NULL,
	Nazwa VARCHAR(40) NOT NULL,
	Kategoria VARCHAR(MAX),
	Cena_Jednostkowa MONEY DEFAULT NULL,
)

INSERT INTO [Produkty](ID_Produktu, Nazwa, Kategoria, Cena_Jednostkowa)
(
SELECT [ProductID], [ProductName], [CategoryName], [UnitPrice]
FROM [Northwind].[dbo].[Products] p
JOIN [Northwind].[dbo].[Categories] c ON c.CategoryID = p.CategoryID
WHERE p.UnitPrice BETWEEN 25 AND 60
)


Zadanie 2.2
SELECT o.OrderID, c.CompanyName, o.OrderDate, o.RequiredDate,
	   o.ShipName, od.ProductID, od.Quantity, od.UnitPrice INTO [Zam�wienia]
FROM [Northwind].[dbo].[Orders] o
JOIN [Northwind].[dbo].[Customers] c ON c.CustomerID = o.CustomerID
JOIN [Northwind].[dbo].[Order Details] od ON od.OrderID = o.OrderID
JOIN dbo.Produkty mp ON mp.ID_Produktu = od.ProductID
WHERE od.ProductID = mp.ID_Produktu;


Zadanie 3
SELECT TOP 3p.Kategoria, COUNT(z.Quantity) FROM Produkty p
JOIN dbo.Zam�wienia z ON z.ProductID = p.ID_Produktu
GROUP BY p.Kategoria
ORDER BY COUNT(z.Quantity) DESC


Zadanie 4
SELECT c.CompanyName, SUM(od.UnitPrice*od.Quantity) AS [Warto��] FROM Customers c
JOIN Orders o ON o.CustomerID = c.CustomerID
JOIN [Order Details] od ON od.OrderID = o.OrderID
GROUP BY c.CompanyName
HAVING SUM(od.UnitPrice*od.Quantity) BETWEEN 1000 AND 3000
ORDER BY [Warto��] DESC


Zadanie 5
CREATE VIEW [vZadanie5]
AS SELECT s.CompanyName, COUNT(o.ShipVia) AS [Ilo�� zlece�] FROM [Northwind].[dbo].[Shippers] s
JOIN [Northwind].[dbo].[Orders] o ON o.ShipVia = s.ShipperID
GROUP BY s.CompanyName

SELECT TOP 1 CompanyName, [Ilo�� zlece�] FROM dbo.[vZadanie5]
ORDER BY [Ilo�� zlece�] ASC;


Zadanie 6
CREATE VIEW [vZadanie6]
AS SELECT p.ProductName, p.UnitPrice AS [Cena jednostkowa] FROM [Northwind].[dbo].[Products] p
WHERE p.ProductName LIKE '[c-p]%' AND p.UnitPrice BETWEEN 10 AND 100 AND UnitPrice != 17 AND UnitPrice != 40

SELECT TOP 5 ProductName, [Cena Jednostkowa] FROM vZadanie6
ORDER BY [Cena Jednostkowa] ASC

*/
