/*/********************** ZAD 1 *******************/
CREATE DATABASE [209332_sr_12_14_gr2];
/********************** ZAD 2 ******************/

use [209332_sr_12_14_gr2];

CREATE TABLE [Produkty]
(
	ID_Produktu BIGINT NOT NULL,
	Nazwa VARCHAR(40) NOT NULL,
	Kategoria VARCHAR(MAX),
	Cena_Jednostkowa MONEY default(0)
);

ALTER TABLE produkty ADD CONSTRAINT PK_ID_Produktu PRIMARY KEY(ID_Produktu);
*/
INSERT INTO [produkty](ID_Produktu, Nazwa, Kategoria, Cena_Jednostkowa)
(SELECT * FROM (
SELECT p.ProductID, p.ProductName, c.CategoryName, p.UnitPrice FROM [NORTHWNDENG].[dbo].Products AS p
	JOIN [NORTHWNDENG].[dbo].Categories AS c ON p.CategoryID = c.CategoryID
	)As tab WHERE tab.UnitPrice>25 AND tab.UnitPrice<=60);

/****************************** ZAD 2.2 **************************/
CREATE VIEW [zamowienia_insert]
AS
SELECT o.OrderID, c.CompanyName , o.OrderDate, o.ShippedDate, s.CompanyName AS NazwaDostawcy, p.ProductID, od.Quantity, p.UnitPrice FROM [NORTHWNDENG].[dbo].Orders AS o
JOIN [NORTHWNDENG].[dbo].Shippers AS s ON s.ShipperID=o.ShipVia
JOIN [NORTHWNDENG].[dbo].Customers AS c ON c.CustomerID=o.CustomerID
JOIN [NORTHWNDENG].[dbo].[Order Details] AS od ON od.OrderID=o.OrderID
JOIN [NORTHWNDENG].[dbo].[Products] AS p ON od.ProductID=p.ProductID
WHERE od.ProductID IN (SELECT ID_Produktu FROM Produkty);

INSERT INTO [209332_sr_12_14_gr2].[dbo].zamowienia  SELECT * FROM [zamowienia_insert];

/***************************** ZAD 3 *****************************/
/*SELECT TOP 3 Kategoria FROM Produkty AS p
JOIN Zam�wienia as z ON z.ProductID=p.ID_produktu;*/


/***************************** ZAD 4 ****************************/
SELECT * FROM
(
SELECT c.CompanyName, SUM(od.UnitPrice*od.Quantity) AS wartosc_zamowienia FROM [NORTHWNDENG].[dbo].Customers AS c
JOIN [NORTHWNDENG].[dbo].[Orders] AS o ON o.CustomerID=c.CustomerID
JOIN [NORTHWNDENG].[dbo].[Order Details] AS od ON od.OrderID=o.OrderID
GROUP BY c.CompanyName
) AS tab
WHERE wartosc_zamowienia BETWEEN 1000 AND 3000
ORDER BY wartosc_zamowienia desc;
/***************************** ZAD 5 ****************************/
CREATE VIEW [zamowienia_view]
AS
SELECT NazwaDostawcy, COUNT(orderID) AS ilosc_zamowien FROM zamowienia
GROUP BY NazwaDostawcy;

SELECT TOP 1 * FROM [zamowienia_view]
Order by ilosc_zamowien;