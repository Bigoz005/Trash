CREATE DATABASE [202121_sr12_14]

CREATE TABLE [Produkty]
	(ID_Produktu BIGINT NOT NULL,
	Nazwa VARCHAR(40) NOT NULL,
	Kategoria VARCHAR(MAX),
	Cena_Jednostkowa MONEY DEFAULT VALUES 0)


CREATE VIEW [vProd] AS
SELECT o.ProductID, o.ProductName, p.CategoryName, o.UnitPrice
	FROM [NORTHWND].[dbo].[Products] as o
	JOIN [NORTHWND].[dbo].[Categories] as p 
	on o.CategoryID=p.CategoryID
	WHERE UnitPrice BETWEEN 25 AND 60

INSERT INTO [Produkty]
	SELECT * FROM [vProd]

INSERT INTO [Zam�wienia]
SELECT o.OrderID, c.CompanyName, o.OrderDate, o.ShippedDate, o.ShipName, ord.ProductID,
	ord.Quantity, ord.UnitPrice
	from [NORTHWND].[dbo].[Orders] as o
	INNER JOIN [NORTHWND].[dbo].[Order Details] as ord on o.OrderID=ord.OrderID
	INNER JOIN [NORTHWND].[dbo].[Customers] as c on o.CustomerID=c.CustomerID

INSERT [vZam] INTO [Zam�wienia]

SELECT c.CompanyName, sum(o.Quantity*o.UnitPrice) FROM [NORTHWND].[dbo].[Customers]
	

