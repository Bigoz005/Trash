---Zad 1
/*
USE [master]
CREATE DATABASE[209499_sr_12_14_gr2]
*/
--Zad 2.1
/*
USE  [209499_sr_12_14_gr2]

CREATE TABLE "Produkty"(
	ID_Product BIGINT NOT NULL,
	Nazwa Varchar(40) NOT NULL,
	Kategoria Varchar(max),
	Cena_jednostkowa BIGINT
);
USE [NORTHWND ENG]
SELECT ProductID, ProductName, CategoryID, UnitPrice FROM Products
WHERE UnitPrice >= 25 AND UnitPrice <=60 

USE [NORTHWND ENG]
SELECT ProductID, ProductName, CategoryID, UnitPrice FROM Products
WHERE UnitPrice >= 25 AND UnitPrice <=60 

USE [209499_sr_12_14_gr2]
INSERT  INTO Produkty(ID_Product, Nazwa, Kategoria, Cena_Jednostkowa) 
				VALUES
						(10,	'Ikura', 8,	31.00),
						(12,	'Queso Manchego La Pastora', 4,	38.00),
						(17,	'Alice Mutton',	6,	39.00),
						(26,	'Gumb�r Gummib�rchen',	3,	31.23),
						(27, 'Schoggi Schokolade',	3,	43.90),
						(28,	'R�ssle Sauerkraut',	7,	45.60),
						(30,	'Nord-Ost Matjeshering',	8,	25.89),
						(32,	'Mascarpone Fabioli',	4,	32.00),
						(37,	'Gravad lax',	8,	26.00),
						(43,	'Ipoh Coffee',	1,	46.00),
						(51,	'Manjimup Dried Apples',	7,	53.00),
						(53,	'Perth Pasties',	6,	32.80),
						(56,	'Gnocchi di nonna Alice',	5,	38.00),
						(59,	'Raclette Courdavault',	4,	55.00),
						(60,	'Camembert Pierrot',	4,	34.00),
						(61,	'Sirop d�rable',	2,	28.50),
						(62,	'Tarte au sucre',	3,	49.30),
						(63,	'Vegie-spread',	2,	43.90),
						(64,	'Wimmers gute Semmelkn�del',	5,	33.25),
						(69,	'Gudbrandsdalsost',	4,	36.00),
						(72,	'Mozzarella di Giovanni',	4,	34.80);
						
*/
--Zad 2.2
USE [NORTHWND ENG]
SELECT o.OrderID, c.CompanyName , o.OrderDate , o.ShippedDate, s.CompanyName, p.ProductID, p.UnitsOnOrder, p.UnitPrice   FROM Orders AS o
 JOIN Customers AS c ON o.CustomerID = c.CustomerID
 JOIN Shippers AS s ON o.ShipVia = s.ShipperID
 JOIN [Order Details] AS od ON o.OrderID = od.OrderID
 JOIN Products AS p ON od.ProductID = p.ProductID
 WHERE P.UnitPrice >= 25 AND P.UnitPrice <=60 

