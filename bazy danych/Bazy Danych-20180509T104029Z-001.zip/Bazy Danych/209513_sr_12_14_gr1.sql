-- Zadanie 1

Create Database [209513_sr_12_14_gr1];

-- Zadanie 2

--Stworzenie tabeli

Create Table Produkty 
(
ID_Produktu bigint not null identity(1,1) primary key, 
Nazwa varchar(40),
Kategoria varchar(max),
Cena_Jednostkowa money default '0'
);

--Uzupe�nienie tabeli

INSERT INTO [Produkty] (Nazwa,Kategoria,Cena_Jednostkowa) 
(SELECT P.ProductName, C.CategoryName, P.UnitPrice FROM [north_eng].[dbo].[Products] AS P 
inner Join [north_eng].[dbo].[Categories] 
as C on P.CategoryID = C.CategoryID where P.UnitPrice between 1 and 20);

--Zadanie3



--Zadanie4

Select c.CompanyName, sum(od.UnitPrice*od.Quantity) as Zamowienia
From (([north_eng].[dbo].[Orders] as o inner join [north_eng].[dbo].[Customers] as c on 
o.CustomerID=c.CustomerID) inner join [north_eng].[dbo].[Order Details] as od on o.OrderID=od.OrderID ) 
group by c.CompanyName
having sum(od.UnitPrice*od.Quantity) between 5000 and 12000
order by Zamowienia

--Zadanie5
--spedytor z najwi�ksz� ilo�ci� zlece�
Select top 1 sh.CompanyName, count(o.ShipVia) as [Ilosc zlecen] 
from [north_eng].[dbo].[Shippers] as sh 
inner join  [north_eng].[dbo].[Orders] as o on sh.ShipperID=o.ShipVia 
group by sh.CompanyName 
order by [Ilosc zlecen];

--Zadanie6
Create View [Zadanie6] As Select Nazwa, Cena_Jednostkowa 
From Produkty where Nazwa between 'c%' and 'p%' and 
Cena_Jednostkowa between 10 and 100 and Cena_Jednostkowa <> 97 and Cena_Jednostkowa <> 10 

--5 produkt�w z najwi�ksz� cen� jednostkow�
Select top 5 ProductID, ProductName, UnitPrice from[north_eng].[dbo].[Products] order by UnitPrice DESC;

