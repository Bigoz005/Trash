/*
CREATE DATABASE [202247_sr_12_14_gr1];


CREATE TABLE [Produkty]
(
 ID_Produktu BIGINT NOT NULL Identity(1,1),
 Nazwa VARCHAR(40) NOT NULL,
 Kategoria VARCHAR(MAX),
 Cena_Jednostkowa MONEY DEFAULT 0);

 */

INSERT INTO [Produkty](ID_Produktu, Nazwa, Cena_Jednostkowa, Kategoria)
(
SELECT p.ProductID, p.ProductName, p.UnitPrice, c.CategoryName
FROM Northwind.dbo.Products AS p
JOIN Northwind.dbo.Categories AS c ON c.CategoryID=p.CategoryID
WHERE p.UnitPrice BETWEEN 1 AND 20);


ALTER TABLE Produkty ADD CONSTRAINT PK_ID_Produktu PRIMARY KEY(ID_Produktu);


SELECT TOP 3 c.CategoryName, SUM(p.UnitPrice) AS wartosc 
FROM Northwind.dbo.Products AS p
JOIN Northwind.dbo.Categories AS c ON c.CategoryID=p.CategoryID
WHERE p.UnitPrice BETWEEN 1 AND 20
GROUP BY CategoryName 
ORDER BY wartosc desc



SELECT p.CompanyName, SUM() AS wartosc 
FROM Northwind.dbo.Suppliers AS p

CREATE VIEW [vProdukty2] AS
SELECT * FROM [north].[dbo].[Spedytorzy]


