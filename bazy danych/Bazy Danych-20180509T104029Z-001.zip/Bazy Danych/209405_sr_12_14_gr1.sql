/*
--zad1.

CREATE DATABASE [209405_sr_12_14_gr1]

USE [209405_sr_12_14_gr1]
--zad2.1

CREATE TABLE [Produkty]
(
ID_Produktu BIGINT NOT NULL,
Nazwa  VARCHAR(40) NOT NULL,
Kategoria VARCHAR(MAX),
Cena_Jednostkowa MONEY DEFAULT 0
);

ALTER TABLE Produkty ADD CONSTRAINT PK_ID_Produktu PRIMARY KEY(ID_Produktu);



INSERT INTO [Produkty](ID_Produktu, Nazwa, Kategoria, Cena_Jednostkowa) 
(SELECT ndp.IDproduktu, ndp.NazwaProduktu, ndk.NazwaKategorii, ndp.CenaJednostkowa
 FROM northwind.dbo.Produkty AS ndp
 INNER JOIN northwind.dbo.Kategorie AS ndk ON ndp.IDKategorii = ndk.IDKategorii 
 WHERE CenaJednostkowa>=1 AND CenaJednostkowa<=20);
 */

  --zad2.2 tabela tymczasowa
  SELECT z.IDzam�wienia, z.NazwaOdbiorcy AS [Nazwa Klienta], d.NazwaFirmy AS [Nazwa Dostawcy], z.DataZam�wienia, z.DataWysy�ki, p.IDproduktu, p.Ilo��Zam�wiona, p.CenaJednostkowa FROM northwind.dbo.Zam�wienia AS z
  JOIN northwind.dbo.klienci AS k ON k.IDklienta=z.IDklienta
  JOIN northwind.dbo.[Opisy zam�wie�] AS o ON o.IDzam�wienia=z.IDzam�wienia
  JOIN northwind.dbo.Produkty AS p ON p.IDproduktu =o.IDproduktu
  JOIN northwind.dbo.Dostawcy AS d ON d.IDdostawcy=p.IDdostawcy
  ORDER BY IDzam�wienia
  

 

  /*
  --zad3

  SELECT TOP 3 tab.Kategoria, tab.Ilosc FROM
  (
  SELECT Kategoria, COUNT(ID_Produktu) AS Ilosc FROM Produkty
  GROUP BY Kategoria) AS tab
  ORDER BY tab.Ilosc DESC;
  */

