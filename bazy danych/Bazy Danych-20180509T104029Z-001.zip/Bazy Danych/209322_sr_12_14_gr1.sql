--zad1
use [master];
create database [209322_ sr_12_14_gr1];
use [209322_ sr_12_14_gr1];

--zad2
create table [Produkty](
ID_Produktu int not null,
Nazwa varchar(40) not null,
Kategoria varchar(max),
Cena_Jednostkowa money
);

alter table Produkty add constraint PK_produkty primary key(ID_Produktu);
alter table Produkty add constraint D_cena default 0 for Cena_Jednostkowa;

insert into [209322_ sr_12_14_gr1].dbo.Produkty(ID_Produktu, Nazwa, Kategoria, Cena_Jednostkowa)
(select p.ProductID, p.ProductName, c.CategoryName, p.UnitPrice from [NORTHWND].dbo.Products as p
join [NORTHWND].dbo.Categories as c on c.CategoryID=p.CategoryID
where p.UnitPrice between 1 and 20);

select distinct o.OrderID, c.CompanyName, o.OrderDate, o.ShippedDate, s.CompanyName as shipper, od.ProductID, od.Quantity, od.Unitprice
into [Zamowienia]
from [NORTHWND].dbo.Orders as o
join [NORTHWND].dbo.[Order Details] as od on o.OrderID=od.OrderID
join [NORTHWND].dbo.[Shippers] as s on o.ShipVia=s.ShipperID
join [NORTHWND].dbo.[Customers] as c on c.CustomerID=o.CustomerID
where od.ProductID in (select ID_produktu from produkty);


--zad3
select top 3 kategoria, count(ID_Produktu) as ilosc from produkty
group by kategoria
order by [ilosc] DESC;

--zad4
select c.CompanyName, sum(od.UnitPrice*od.Quantity) as [suma zamowien] 
from [NORTHWND].dbo.customers as c
join [NORTHWND].dbo.orders as o on o.CustomerID=c.CustomerID
join [NORTHWND].dbo.[order details] as od on od.OrderID=o.OrderID
group by c.CompanyName
having sum(od.UnitPrice*od.Quantity) between 5000 and 12000
order by [suma zamowien] ASC;

--zad5
create view zad5 as
select s.CompanyName, count(o.ShipVia) as [ilosc zlecen]
from [NORTHWND].dbo.Shippers as s
join [NORTHWND].dbo.[orders] as o on o.ShipVia=s.ShipperID
group by s.CompanyName;

select top 1 * from zad5
order by [ilosc zlecen] DESC;

--zad6
create view zad6 as
select productname, unitprice from [NORTHWND].dbo.products
where lower(productname) like '[c-p]%' 
and unitPrice between 10 and 100 
and unitPrice not in ('97','10');

select top 5 * from zad6
order by [UnitPrice] DESC;






