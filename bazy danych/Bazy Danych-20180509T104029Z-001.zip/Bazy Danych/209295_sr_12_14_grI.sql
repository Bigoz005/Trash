
/*
Zadanie 1
CREATE DATABASE 209295_sr_12_14_gr1]

Zadanie 2.1
CREATE TABLE Produkty (
ID_Produktu INTEGER PRIMARY KEY NOT NULL,
Nazwa varchar(40) NOT NULL,
Kategoria varchar(MAX),
Cena_Jednostkowa MONEY DEFAULT 0);


insert into [Produkty](ID_Produktu,Nazwa,Kategoria,Cena_Jednostkowa)
					(Select p.ProductID, p.ProductName, c.CategoryName, p.UnitPrice from [NORTHWND ENG].dbo.Products as p
						join [NORTHWND ENG].dbo.Categories as c on c.CategoryID=p.CategoryID
						where p.UnitPrice between 1 AND 20)

select * from Produkty
Zadanie 2.2
Select o.OrderID,c.CompanyName as Client,o.OrderDate,o.ShippedDate,s.CompanyName,p.ProductID,od.Quantity,od.UnitPrice into [Zamowienia] from [NORTHWND ENG].dbo.Orders as o
					 join [NORTHWND ENG].dbo.[Order Details] as od on o.OrderID=od.OrderID
					 join [NORTHWND ENG].dbo.[Customers] as c on o.CustomerID=c.CustomerID
					 join [NORTHWND ENG].dbo.[Shippers] as s on o.ShipVia=s.ShipperID
					 join [NORTHWND ENG].dbo.[Products] as p on od.ProductID=p.ProductID
					 where p.UnitsOnOrder>0


Zadanie 3
 Select top 3 p.Kategoria,sum(z.Quantity) as ilosc_zamowionych from Produkty as p
 join Zamowienia as z on z.ProductID=p.ID_Produktu
 group by p.Kategoria
 order by ilosc_zamowionych desc


  4. Wy�wietl nazwy firm oraz sum� warto�ci ich zam�wie� od 5000 do 12000 
  posortowanych od A-Z po warto�ciach. Baza danych Northwind.
  
  select c.CompanyName, sum(od.UnitPrice*od.Quantity) as Wartosc_Zamowienia from Customers as c
  join Orders as o on o.CustomerID=c.CustomerID
  join [Order Details] as od on od.OrderID=o.OrderID
  group by c.CompanyName
  having sum(od.UnitPrice*od.Quantity)>5000 AND sum(od.UnitPrice*od.Quantity)<12000
  order by Wartosc_Zamowienia asc

 

	5. Stworzy� w bazie danych z pkt.1. widok wy�wietlaj�cy nazwy oraz ilo�� zlece� spedytor�w.
	 Nast�pnie wy�wietli� spedytora z najwi�ksz� ilo�ci� zlece�. Baza danych Northwind.
	 


NORTH

create view VspedycjaTEST
as 
select 
s.CompanyName, count(od.OrderID) as liczba from [NORTHWND ENG].dbo.Shippers as s
join [NORTHWND ENG].dbo.Orders as o on s.ShipperID=o.ShipVia
join [NORTHWND ENG].dbo.[Order Details] as od on o.OrderId=od.OrderID
group by s.CompanyName

select top 1 CompanyName, max(liczba) as Liczba_Zamowien from VspedycjaTEST
group by CompanyName
order by Liczba_zamowien desc 
 */