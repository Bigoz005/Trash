--Zadanie1
CREATE DATABASE [209373_sr_12_14_gr2];

USE [209373_sr_12_14_gr2];

CREATE TABLE [Produkty](
	ID_Produktu BIGINT NOT NULL PRIMARY KEY,
	Nazwa varchar(40) NOT NULL,
	Kategoria VARCHAR(MAX),
	Cena_Jednostkowa money
);
--Zadanie 2.1
INSERT INTO [Produkty](ID_Produktu,Nazwa,Kategoria,Cena_Jednostkowa)
			 (SELECT p.ProductID, p.ProductName, c.CategoryName, p.UnitPrice FROM [NORTHWND].[dbo].[Products] AS p INNER JOIN [NORTHWND].[dbo].[Categories] AS c ON p.CategoryID = c.CategoryID
			 WHERE p.UnitPrice BETWEEN 25 AND 60
			 );

SELECT * FROM Produkty

--Zadanie 2.2



--Zadanie 3

--Zadanie 4
SELECT c.CompanyName, SUM(od.UnitPrice * od.Quantity)
FROM [NORTHWND].[dbo].[Customers] AS c INNER JOIN [NORTHWND].[dbo].[Orders] AS o ON c.CustomerID = o.CustomerID 
INNER JOIN [NORTHWND].[dbo].[Order Details] AS od ON o.OrderID = od.OrderID
GROUP BY c.CompanyName
HAVING SUM(od.UnitPrice * od.Quantity) BETWEEN 1000 AND 3000
ORDER BY c.CompanyName DESC


--Zadanie 5

CREATE VIEW [POKAZ]
AS
(
SELECT s.CompanyName, COUNT(s.ShipperID) AS Suma FROM [NORTHWND].[dbo].[Shippers] AS s INNER JOIN [NORTHWND].[dbo].[Orders] AS o ON s.ShipperID = o.ShipVia
GROUP By s.CompanyName
);

SELECT TOP 1 * FROM [POKAZ]
ORDER BY [POKAZ].Suma ASC


--Zadanie 6
CREATE VIEW [POKAZ_2]
AS
(
SELECT p.ProductName, p.UnitPrice FROM [NORTHWND].[dbo].[Products] AS p
WHERE p.UnitPrice BETWEEN 10 AND 100 AND [UnitPrice] <> '17' AND [UnitPrice] <> '40' AND p.ProductName BETWEEN 'c%' AND 'p%'
);

SELECT TOP 5 * FROM [POKAZ_2]
ORDER BY [POKAZ_2].UnitPrice ASC