use [master];
go
create database [209467_sr_12_14_gr1];
go
use [209467_sr_12_14_gr1];



--ZADANIE 2
--2.1.
CREATE TABLE [Produkty]
(
	ID_Produktu BIGINT NOT NULL primary key,
	Nazwa VARCHAR(40) NOT NULL,
	Kategoria VARCHAR(max),
	Cena_Jednostkowa money default(0)
);


insert into [Produkty](ID_Produktu, Nazwa, Kategoria, Cena_Jednostkowa)
(select p.ProductID, p.ProductName, c.CategoryName, p.UnitPrice
from [Northwind].[dbo].[Products] as p
inner join [Northwind].[dbo].[Categories] as c on p.CategoryID = c.CategoryID
where p.UnitPrice between 1 and 20);


--2.2.
select o.OrderID, c.CompanyName as Nazwa_Klienta, o.OrderDate, o.ShippedDate, s.CompanyName as Nazwa_Dostawcy, p.ProductID, od.Quantity, od.UnitPrice into [Zam�wienia]
from [Northwind].[dbo].[Products] as p
inner join [Northwind].[dbo].[Suppliers] as s on s.SupplierID = p.SupplierID
inner join [Northwind].[dbo].[Order Details] as od on od.ProductID = p.ProductID
inner join [Northwind].[dbo].[Orders] as o on o.OrderID = od.OrderID
inner join [Northwind].[dbo].[Customers] as c on c.CustomerID = o.CustomerID
where exists (select * from [Produkty]);

--ZADANIE 3
select distinct top 3 p.Kategoria, z.Quantity from Produkty as p
join Zam�wienia as z on p.ID_Produktu = z.ProductID
group by p.Kategoria, z.Quantity
order by z.Quantity desc;


--ZADANIE 4
select c.CompanyName, sum(od.UnitPrice*od.Quantity) as wartosc from Customers as c
inner join Orders as o on o.CustomerID=c.CustomerID
inner join [Order Details] as od on od.OrderID=o.OrderID
group by c.CompanyName
having sum(od.UnitPrice*od.Quantity) between 5000 and 12000
order by wartosc asc;
